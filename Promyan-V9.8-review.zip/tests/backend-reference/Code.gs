// Promyan V9.5 owner-login edition. Server file only.
// ตั้งบัญชีในฟังก์ชันนี้ แล้วเลือก setupOwnerAccount > Run ใน Apps Script
// รันสำเร็จแล้วลบค่าทั้งสองกลับเป็น '' และ Save ก่อน Deploy (อย่าอัปโหลดค่าจริงขึ้น GitHub)
function setupOwnerAccount() {
  var USERNAME = ''; // กรอกชื่อผู้ใช้ที่นี่ (3–64 ตัวอักษร)
  var PASSWORD = ''; // กรอกรหัสผ่านที่นี่ (อย่างน้อย 15 ตัวอักษร สูงสุด 128)
  promyanInstallOwner_(USERNAME, PASSWORD);
}

var PROMYAN_AUTH_PROTOCOL = 'promyan-auth-v1';
var PROMYAN_PASSWORD_ROUNDS = 600000;
var PROMYAN_SESSION_MS = 8 * 60 * 60 * 1000;
var PROMYAN_AUTH_PROPERTY = 'PROMYAN_OWNER_V1';
var PROMYAN_SESSION_PROPERTY = 'PROMYAN_SESSION_V1';
var PROMYAN_ATTEMPTS_PROPERTY = 'PROMYAN_LOGIN_ATTEMPTS_V1';

function promyanInstallOwner_(username, password) {
  if (typeof username !== 'string' || username.trim().length < 3 || username.trim().length > 64
      || typeof password !== 'string' || password.length < 15 || password.length > 128) {
    throw new Error('กรอก Username 3–64 ตัวอักษร และ Password 15–128 ตัวอักษรใน setupOwnerAccount ก่อนรัน');
  }
  var salt = (Utilities.getUuid() + Utilities.getUuid()).replace(/-/g, '');
  var account = {username:username.trim(), salt:salt, rounds:PROMYAN_PASSWORD_ROUNDS,
    verifier:promyanPasswordHash_(password, salt, PROMYAN_PASSWORD_ROUNDS)};
  var lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    var props = PropertiesService.getScriptProperties();
    props.setProperty(PROMYAN_AUTH_PROPERTY, JSON.stringify(account));
    props.deleteProperty(PROMYAN_SESSION_PROPERTY);
    props.deleteProperty(PROMYAN_ATTEMPTS_PROPERTY);
  } finally { lock.releaseLock(); }
  // Never log credentials, hashes or session tokens.
  console.log('ตั้งบัญชีสำเร็จแล้ว กรุณาลบ Username/Password ในโค้ดกลับเป็นช่องว่าง แล้ว Save ก่อน Deploy');
}

// Run manually in the editor to revoke all sessions (also useful for a lost device).
function revokeOwnerSessions() {
  var lock = LockService.getScriptLock(); lock.waitLock(30000);
  try { PropertiesService.getScriptProperties().deleteProperty(PROMYAN_SESSION_PROPERTY); }
  finally { lock.releaseLock(); }
}
function promyanPasswordHash_(password, salt, rounds) {
  return sjcl.codec.hex.fromBits(sjcl.misc.pbkdf2(password, sjcl.codec.hex.toBits(salt), rounds, 256));
}
function promyanTokenHash_(token) {
  return sjcl.codec.hex.fromBits(sjcl.hash.sha256.hash(token));
}
function promyanEqual_(a,b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  var diff = a.length ^ b.length;
  for (var i=0; i<Math.max(a.length,b.length); i++) diff |= (a.charCodeAt(i)||0) ^ (b.charCodeAt(i)||0);
  return diff === 0;
}
function promyanOwner_() {
  var raw = PropertiesService.getScriptProperties().getProperty(PROMYAN_AUTH_PROPERTY);
  if (!raw) return null;
  var a = JSON.parse(raw);
  if (!a || typeof a.username !== 'string' || a.username.length < 3 || a.username.length > 64
      || !/^[a-f0-9]{64}$/.test(a.salt) || !/^[a-f0-9]{64}$/.test(a.verifier)
      || a.rounds !== PROMYAN_PASSWORD_ROUNDS) return null;
  return a;
}
// Caller holds ScriptLock, so logout/credential changes cannot race an accepted write.
function promyanSession_(token) {
  if (typeof token !== 'string' || !/^[a-f0-9]{64}$/.test(token)) return null;
  var owner = promyanOwner_();
  if (!owner) return null;
  var raw = PropertiesService.getScriptProperties().getProperty(PROMYAN_SESSION_PROPERTY);
  if (!raw) return null;
  var s = JSON.parse(raw);
  if (!s || typeof s.expiresAt !== 'number' || Date.now() >= s.expiresAt
      || !promyanEqual_(s.hash, promyanTokenHash_(token))) return null;
  return s;
}
function promyanAuthReply_(ok, extra) {
  return promyanJson_(Object.assign({protocol:PROMYAN_AUTH_PROTOCOL,ok:ok},extra));
}
function promyanAuth_(p) {
  var lock, acquired = false;
  try {
    if (!p || p.protocol !== PROMYAN_AUTH_PROTOCOL || ['login','session','logout'].indexOf(p.action) < 0)
      return promyanAuthReply_(false,{code:'INVALID_REQUEST'});
    lock = LockService.getScriptLock(); acquired = lock.tryLock(10000);
    if (!acquired) return promyanAuthReply_(false,{code:'BUSY'});
    var owner = promyanOwner_();
    if (!owner) return promyanAuthReply_(false,{code:'AUTH_NOT_CONFIGURED'});
    var props = PropertiesService.getScriptProperties();
    if (p.action !== 'login') {
      var session = promyanSession_(p.token);
      if (!session) return promyanAuthReply_(false,{code:'UNAUTHORIZED'});
      if (p.action === 'logout') {
        props.deleteProperty(PROMYAN_SESSION_PROPERTY);
        return promyanAuthReply_(true,{status:'logged_out'});
      }
      return promyanAuthReply_(true,{status:'authenticated',expiresAt:session.expiresAt});
    }
    // One owner, one global persistent limit; changing the supplied username cannot bypass it.
    var now = Date.now(), windowMs = 15 * 60 * 1000;
    var attempts = JSON.parse(props.getProperty(PROMYAN_ATTEMPTS_PROPERTY) || 'null');
    if (!attempts || now >= attempts.until) attempts = {count:0,until:now+windowMs};
    if (attempts.count >= 5) return promyanAuthReply_(false,{code:'RATE_LIMITED',retryAfterSeconds:Math.ceil((attempts.until-now)/1000)});
    attempts.count++;
    props.setProperty(PROMYAN_ATTEMPTS_PROPERTY,JSON.stringify(attempts));
    if (typeof p.username !== 'string' || p.username.length > 64 || typeof p.password !== 'string'
        || p.password.length < 1 || p.password.length > 128
        || typeof p.sessionCandidate !== 'string' || !/^[a-f0-9]{64}$/.test(p.sessionCandidate)) {
      return promyanAuthReply_(false,{code:'INVALID_CREDENTIALS'});
    }
    // Do the expensive hash even for an incorrect username; identical error messages.
    var hash = promyanPasswordHash_(p.password,owner.salt,owner.rounds);
    var userOK = promyanEqual_(p.username.trim(),owner.username);
    var passOK = promyanEqual_(hash,owner.verifier);
    if (!userOK || !passOK) return promyanAuthReply_(false,{code:'INVALID_CREDENTIALS'});
    // The browser creates a fresh 256-bit CSPRNG token for each password-authenticated login.
    // Only its digest is stored on the server. Re-login revokes the previous session.
    var expiresAt = Date.now() + PROMYAN_SESSION_MS;
    props.setProperty(PROMYAN_SESSION_PROPERTY,JSON.stringify({hash:promyanTokenHash_(p.sessionCandidate),expiresAt:expiresAt}));
    props.deleteProperty(PROMYAN_ATTEMPTS_PROPERTY);
    return promyanAuthReply_(true,{status:'authenticated',token:p.sessionCandidate,expiresAt:expiresAt});
  } catch (error) { return promyanAuthReply_(false,{code:'AUTH_UNAVAILABLE'}); }
  finally { if (acquired) lock.releaseLock(); }
}

// Promyan V9.5 confirmed-save companion. Not deployed automatically.
// Script Properties: SPREADSHEET_ID and SHEET_NAME (both required).
// Keep existing A:D: timestamp, name, dob, note. Reserve E:F for metadata.
// Set E1=request_id and F1=saved_at manually before deployment.
var PROMYAN_PROTOCOL = 'promyan-save-v1';
var PROMYAN_META_HEADERS = ['request_id','saved_at'];

function promyanJson_(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}
function promyanConfig_() {
  var props = PropertiesService.getScriptProperties();
  return {id:props.getProperty('SPREADSHEET_ID'), tab:props.getProperty('SHEET_NAME')};
}
function doGet(e) {
  if (!e || !e.parameter || e.parameter.action !== 'health') {
    return promyanJson_({protocol:PROMYAN_PROTOCOL, ok:false, code:'UNSUPPORTED_ACTION'});
  }
  // Read-only probe: no records, names or DOBs are returned.
  try {
    if (!promyanOwner_()) return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:true,ready:false,authRequired:true,code:'AUTH_NOT_CONFIGURED'});
    var config = promyanConfig_();
    if (!config.id || !config.tab) return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:true,ready:false,code:'NOT_CONFIGURED'});
    var sheet = SpreadsheetApp.openById(config.id).getSheetByName(config.tab);
    if (!sheet) return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:true,ready:false,code:'SHEET_NOT_FOUND'});
    if (!promyanSchema_(sheet)) return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:true,ready:false,code:'SCHEMA_MISMATCH'});
    return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:true,ready:true,authRequired:true});
  } catch (error) {
    return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:false,ready:false,code:'NOT_READY'});
  }
}
function promyanSchema_(sheet) {
  return sheet.getLastRow() >= 1 && JSON.stringify(sheet.getRange(1,5,1,2).getDisplayValues()[0]) === JSON.stringify(PROMYAN_META_HEADERS);
}

function promyanValidate_(p) {
  if (!p || p.protocol !== PROMYAN_PROTOCOL || p.action !== 'save'
      || typeof p.requestId !== 'string' || !/^[a-f0-9-]{36}$/i.test(p.requestId)
      || typeof p.timestamp !== 'string' || p.timestamp.length > 50 || !isFinite(Date.parse(p.timestamp))) return false;
  if (['name','dob','note'].some(function(k){return typeof p[k] !== 'string';})) return false;
  return Boolean(p.name.trim() || p.dob.trim()) && p.name.length <= 200 && p.dob.length <= 200 && p.note.length <= 2000;
}
function promyanText_(value) {
  // Store user text as text, never as a spreadsheet formula.
  return /^[=+\-@\t\r\n']/.test(value) ? "'" + value : value;
}
function doPost(e) {
  var p, lock, acquired = false;
  try {
    var raw = e && e.postData && e.postData.contents;
    if (!raw || raw.length > 10000) return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:false,code:'INVALID_BODY'});
    p = JSON.parse(raw);
    if (p && ['login','session','logout'].indexOf(p.action) >= 0) return promyanAuth_(p);
    if (!promyanValidate_(p)) return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:false,code:'INVALID_REQUEST'});
    lock = LockService.getScriptLock();
    acquired = lock.tryLock(10000);
    if (!acquired) return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:false,requestId:p.requestId,code:'BUSY'});
    if (!promyanSession_(p.token)) return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:false,code:'UNAUTHORIZED'});
    var config = promyanConfig_();
    if (!config.id || !config.tab) return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:false,requestId:p.requestId,code:'NOT_CONFIGURED'});
    var book = SpreadsheetApp.openById(config.id);
    var sheet = book.getSheetByName(config.tab);
    if (!sheet) return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:false,requestId:p.requestId,code:'SHEET_NOT_FOUND'});
    // No automatic header changes or migration of historical records.
    if (!promyanSchema_(sheet)) {
      return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:false,requestId:p.requestId,code:'SCHEMA_MISMATCH'});
    }
    var last = sheet.getLastRow();
    var match = last > 1 ? sheet.getRange(2,5,last-1,1).createTextFinder(p.requestId).matchEntireCell(true).findNext() : null;
    var row, savedAt, status;
    if (match) {
      row = match.getRow();
      var existing = sheet.getRange(row,1,1,6).getDisplayValues()[0];
      if (JSON.stringify(existing.slice(0,4)) !== JSON.stringify([p.timestamp,p.name,p.dob,p.note])) {
        return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:false,requestId:p.requestId,code:'REQUEST_ID_CONFLICT'});
      }
      savedAt = existing[5]; status = 'duplicate';
      if (!savedAt || !isFinite(Date.parse(savedAt))) return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:false,requestId:p.requestId,code:'READBACK_FAILED'});
    } else {
      row = last + 1; savedAt = new Date().toISOString(); status = 'saved';
      var stored = [p.timestamp,p.name,p.dob,p.note,p.requestId,savedAt].map(promyanText_);
      sheet.getRange(row,1,1,6).setNumberFormat('@').setValues([stored]);
      SpreadsheetApp.flush();
    }
    // Success is returned ONLY after reading the row back and checking its data.
    var actual = sheet.getRange(row,1,1,6).getDisplayValues()[0];
    var expected = [p.timestamp,p.name,p.dob,p.note,p.requestId,savedAt];
    if (JSON.stringify(actual) !== JSON.stringify(expected)) {
      return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:false,requestId:p.requestId,code:'READBACK_FAILED'});
    }
    return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:true,verified:true,requestId:p.requestId,status:status,row:row,savedAt:savedAt});
  } catch (error) {
    // Do not leak sheet identifiers or user data to a public response/log.
    return promyanJson_({protocol:PROMYAN_PROTOCOL,ok:false,requestId:p && p.requestId,code:'SAVE_NOT_CONFIRMED'});
  } finally {
    if (acquired) lock.releaseLock();
  }
}

/* Bundled SJCL 1.0.8 subset (unmodified source); BSD-2-Clause.
SJCL is open. You can use, modify and redistribute it under a BSD
license or under the GNU GPL, version 2.0.

---------------------------------------------------------------------

http://opensource.org/licenses/BSD-2-Clause

Copyright (c) 2009-2015, Emily Stark, Mike Hamburg and Dan Boneh at
Stanford University. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---------------------------------------------------------------------

http://opensource.org/licenses/GPL-2.0

The Stanford Javascript Crypto Library (hosted here on GitHub) is a
project by the Stanford Computer Security Lab to build a secure,
powerful, fast, small, easy-to-use, cross-browser library for
cryptography in Javascript.

Copyright (c) 2009-2015, Emily Stark, Mike Hamburg and Dan Boneh at
Stanford University.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/
/** @fileOverview Javascript cryptography implementation.
 *
 * Crush to remove comments, shorten variable names and
 * generally reduce transmission size.
 *
 * @author Emily Stark
 * @author Mike Hamburg
 * @author Dan Boneh
 */

"use strict";
/*jslint indent: 2, bitwise: false, nomen: false, plusplus: false, white: false, regexp: false */
/*global document, window, escape, unescape, module, require, Uint32Array */

/**
 * The Stanford Javascript Crypto Library, top-level namespace.
 * @namespace
 */
var sjcl = {
  /**
   * Symmetric ciphers.
   * @namespace
   */
  cipher: {},

  /**
   * Hash functions.  Right now only SHA256 is implemented.
   * @namespace
   */
  hash: {},

  /**
   * Key exchange functions.  Right now only SRP is implemented.
   * @namespace
   */
  keyexchange: {},
  
  /**
   * Cipher modes of operation.
   * @namespace
   */
  mode: {},

  /**
   * Miscellaneous.  HMAC and PBKDF2.
   * @namespace
   */
  misc: {},
  
  /**
   * Bit array encoders and decoders.
   * @namespace
   *
   * @description
   * The members of this namespace are functions which translate between
   * SJCL's bitArrays and other objects (usually strings).  Because it
   * isn't always clear which direction is encoding and which is decoding,
   * the method names are "fromBits" and "toBits".
   */
  codec: {},
  
  /**
   * Exceptions.
   * @namespace
   */
  exception: {
    /**
     * Ciphertext is corrupt.
     * @constructor
     */
    corrupt: function(message) {
      this.toString = function() { return "CORRUPT: "+this.message; };
      this.message = message;
    },
    
    /**
     * Invalid parameter.
     * @constructor
     */
    invalid: function(message) {
      this.toString = function() { return "INVALID: "+this.message; };
      this.message = message;
    },
    
    /**
     * Bug or missing feature in SJCL.
     * @constructor
     */
    bug: function(message) {
      this.toString = function() { return "BUG: "+this.message; };
      this.message = message;
    },

    /**
     * Something isn't ready.
     * @constructor
     */
    notReady: function(message) {
      this.toString = function() { return "NOT READY: "+this.message; };
      this.message = message;
    }
  }
};

/** @fileOverview Arrays of bits, encoded as arrays of Numbers.
 *
 * @author Emily Stark
 * @author Mike Hamburg
 * @author Dan Boneh
 */

/**
 * Arrays of bits, encoded as arrays of Numbers.
 * @namespace
 * @description
 * <p>
 * These objects are the currency accepted by SJCL's crypto functions.
 * </p>
 *
 * <p>
 * Most of our crypto primitives operate on arrays of 4-byte words internally,
 * but many of them can take arguments that are not a multiple of 4 bytes.
 * This library encodes arrays of bits (whose size need not be a multiple of 8
 * bits) as arrays of 32-bit words.  The bits are packed, big-endian, into an
 * array of words, 32 bits at a time.  Since the words are double-precision
 * floating point numbers, they fit some extra data.  We use this (in a private,
 * possibly-changing manner) to encode the number of bits actually  present
 * in the last word of the array.
 * </p>
 *
 * <p>
 * Because bitwise ops clear this out-of-band data, these arrays can be passed
 * to ciphers like AES which want arrays of words.
 * </p>
 */
sjcl.bitArray = {
  /**
   * Array slices in units of bits.
   * @param {bitArray} a The array to slice.
   * @param {Number} bstart The offset to the start of the slice, in bits.
   * @param {Number} bend The offset to the end of the slice, in bits.  If this is undefined,
   * slice until the end of the array.
   * @return {bitArray} The requested slice.
   */
  bitSlice: function (a, bstart, bend) {
    a = sjcl.bitArray._shiftRight(a.slice(bstart/32), 32 - (bstart & 31)).slice(1);
    return (bend === undefined) ? a : sjcl.bitArray.clamp(a, bend-bstart);
  },

  /**
   * Extract a number packed into a bit array.
   * @param {bitArray} a The array to slice.
   * @param {Number} bstart The offset to the start of the slice, in bits.
   * @param {Number} blength The length of the number to extract.
   * @return {Number} The requested slice.
   */
  extract: function(a, bstart, blength) {
    // FIXME: this Math.floor is not necessary at all, but for some reason
    // seems to suppress a bug in the Chromium JIT.
    var x, sh = Math.floor((-bstart-blength) & 31);
    if ((bstart + blength - 1 ^ bstart) & -32) {
      // it crosses a boundary
      x = (a[bstart/32|0] << (32 - sh)) ^ (a[bstart/32+1|0] >>> sh);
    } else {
      // within a single word
      x = a[bstart/32|0] >>> sh;
    }
    return x & ((1<<blength) - 1);
  },

  /**
   * Concatenate two bit arrays.
   * @param {bitArray} a1 The first array.
   * @param {bitArray} a2 The second array.
   * @return {bitArray} The concatenation of a1 and a2.
   */
  concat: function (a1, a2) {
    if (a1.length === 0 || a2.length === 0) {
      return a1.concat(a2);
    }
    
    var last = a1[a1.length-1], shift = sjcl.bitArray.getPartial(last);
    if (shift === 32) {
      return a1.concat(a2);
    } else {
      return sjcl.bitArray._shiftRight(a2, shift, last|0, a1.slice(0,a1.length-1));
    }
  },

  /**
   * Find the length of an array of bits.
   * @param {bitArray} a The array.
   * @return {Number} The length of a, in bits.
   */
  bitLength: function (a) {
    var l = a.length, x;
    if (l === 0) { return 0; }
    x = a[l - 1];
    return (l-1) * 32 + sjcl.bitArray.getPartial(x);
  },

  /**
   * Truncate an array.
   * @param {bitArray} a The array.
   * @param {Number} len The length to truncate to, in bits.
   * @return {bitArray} A new array, truncated to len bits.
   */
  clamp: function (a, len) {
    if (a.length * 32 < len) { return a; }
    a = a.slice(0, Math.ceil(len / 32));
    var l = a.length;
    len = len & 31;
    if (l > 0 && len) {
      a[l-1] = sjcl.bitArray.partial(len, a[l-1] & 0x80000000 >> (len-1), 1);
    }
    return a;
  },

  /**
   * Make a partial word for a bit array.
   * @param {Number} len The number of bits in the word.
   * @param {Number} x The bits.
   * @param {Number} [_end=0] Pass 1 if x has already been shifted to the high side.
   * @return {Number} The partial word.
   */
  partial: function (len, x, _end) {
    if (len === 32) { return x; }
    return (_end ? x|0 : x << (32-len)) + len * 0x10000000000;
  },

  /**
   * Get the number of bits used by a partial word.
   * @param {Number} x The partial word.
   * @return {Number} The number of bits used by the partial word.
   */
  getPartial: function (x) {
    return Math.round(x/0x10000000000) || 32;
  },

  /**
   * Compare two arrays for equality in a predictable amount of time.
   * @param {bitArray} a The first array.
   * @param {bitArray} b The second array.
   * @return {boolean} true if a == b; false otherwise.
   */
  equal: function (a, b) {
    if (sjcl.bitArray.bitLength(a) !== sjcl.bitArray.bitLength(b)) {
      return false;
    }
    var x = 0, i;
    for (i=0; i<a.length; i++) {
      x |= a[i]^b[i];
    }
    return (x === 0);
  },

  /** Shift an array right.
   * @param {bitArray} a The array to shift.
   * @param {Number} shift The number of bits to shift.
   * @param {Number} [carry=0] A byte to carry in
   * @param {bitArray} [out=[]] An array to prepend to the output.
   * @private
   */
  _shiftRight: function (a, shift, carry, out) {
    var i, last2=0, shift2;
    if (out === undefined) { out = []; }
    
    for (; shift >= 32; shift -= 32) {
      out.push(carry);
      carry = 0;
    }
    if (shift === 0) {
      return out.concat(a);
    }
    
    for (i=0; i<a.length; i++) {
      out.push(carry | a[i]>>>shift);
      carry = a[i] << (32-shift);
    }
    last2 = a.length ? a[a.length-1] : 0;
    shift2 = sjcl.bitArray.getPartial(last2);
    out.push(sjcl.bitArray.partial(shift+shift2 & 31, (shift + shift2 > 32) ? carry : out.pop(),1));
    return out;
  },
  
  /** xor a block of 4 words together.
   * @private
   */
  _xor4: function(x,y) {
    return [x[0]^y[0],x[1]^y[1],x[2]^y[2],x[3]^y[3]];
  },

  /** byteswap a word array inplace.
   * (does not handle partial words)
   * @param {sjcl.bitArray} a word array
   * @return {sjcl.bitArray} byteswapped array
   */
  byteswapM: function(a) {
    var i, v, m = 0xff00;
    for (i = 0; i < a.length; ++i) {
      v = a[i];
      a[i] = (v >>> 24) | ((v >>> 8) & m) | ((v & m) << 8) | (v << 24);
    }
    return a;
  }
};

/** @fileOverview Bit array codec implementations.
 *
 * @author Emily Stark
 * @author Mike Hamburg
 * @author Dan Boneh
 */

/**
 * UTF-8 strings
 * @namespace
 */
sjcl.codec.utf8String = {
  /** Convert from a bitArray to a UTF-8 string. */
  fromBits: function (arr) {
    var out = "", bl = sjcl.bitArray.bitLength(arr), i, tmp;
    for (i=0; i<bl/8; i++) {
      if ((i&3) === 0) {
        tmp = arr[i/4];
      }
      out += String.fromCharCode(tmp >>> 8 >>> 8 >>> 8);
      tmp <<= 8;
    }
    return decodeURIComponent(escape(out));
  },

  /** Convert from a UTF-8 string to a bitArray. */
  toBits: function (str) {
    str = unescape(encodeURIComponent(str));
    var out = [], i, tmp=0;
    for (i=0; i<str.length; i++) {
      tmp = tmp << 8 | str.charCodeAt(i);
      if ((i&3) === 3) {
        out.push(tmp);
        tmp = 0;
      }
    }
    if (i&3) {
      out.push(sjcl.bitArray.partial(8*(i&3), tmp));
    }
    return out;
  }
};

/** @fileOverview Bit array codec implementations.
 *
 * @author Emily Stark
 * @author Mike Hamburg
 * @author Dan Boneh
 */

/**
 * Hexadecimal
 * @namespace
 */
sjcl.codec.hex = {
  /** Convert from a bitArray to a hex string. */
  fromBits: function (arr) {
    var out = "", i;
    for (i=0; i<arr.length; i++) {
      out += ((arr[i]|0)+0xF00000000000).toString(16).substr(4);
    }
    return out.substr(0, sjcl.bitArray.bitLength(arr)/4);//.replace(/(.{8})/g, "$1 ");
  },
  /** Convert from a hex string to a bitArray. */
  toBits: function (str) {
    var i, out=[], len;
    str = str.replace(/\s|0x/g, "");
    len = str.length;
    str = str + "00000000";
    for (i=0; i<str.length; i+=8) {
      out.push(parseInt(str.substr(i,8),16)^0);
    }
    return sjcl.bitArray.clamp(out, len*4);
  }
};


/** @fileOverview Javascript SHA-256 implementation.
 *
 * An older version of this implementation is available in the public
 * domain, but this one is (c) Emily Stark, Mike Hamburg, Dan Boneh,
 * Stanford University 2008-2010 and BSD-licensed for liability
 * reasons.
 *
 * Special thanks to Aldo Cortesi for pointing out several bugs in
 * this code.
 *
 * @author Emily Stark
 * @author Mike Hamburg
 * @author Dan Boneh
 */

/**
 * Context for a SHA-256 operation in progress.
 * @constructor
 */
sjcl.hash.sha256 = function (hash) {
  if (!this._key[0]) { this._precompute(); }
  if (hash) {
    this._h = hash._h.slice(0);
    this._buffer = hash._buffer.slice(0);
    this._length = hash._length;
  } else {
    this.reset();
  }
};

/**
 * Hash a string or an array of words.
 * @static
 * @param {bitArray|String} data the data to hash.
 * @return {bitArray} The hash value, an array of 16 big-endian words.
 */
sjcl.hash.sha256.hash = function (data) {
  return (new sjcl.hash.sha256()).update(data).finalize();
};

sjcl.hash.sha256.prototype = {
  /**
   * The hash's block size, in bits.
   * @constant
   */
  blockSize: 512,
   
  /**
   * Reset the hash state.
   * @return this
   */
  reset:function () {
    this._h = this._init.slice(0);
    this._buffer = [];
    this._length = 0;
    return this;
  },
  
  /**
   * Input several words to the hash.
   * @param {bitArray|String} data the data to hash.
   * @return this
   */
  update: function (data) {
    if (typeof data === "string") {
      data = sjcl.codec.utf8String.toBits(data);
    }
    var i, b = this._buffer = sjcl.bitArray.concat(this._buffer, data),
        ol = this._length,
        nl = this._length = ol + sjcl.bitArray.bitLength(data);
    if (nl > 9007199254740991){
      throw new sjcl.exception.invalid("Cannot hash more than 2^53 - 1 bits");
    }

    if (typeof Uint32Array !== 'undefined') {
	var c = new Uint32Array(b);
    	var j = 0;
    	for (i = 512+ol - ((512+ol) & 511); i <= nl; i+= 512) {
      	    this._block(c.subarray(16 * j, 16 * (j+1)));
      	    j += 1;
    	}
    	b.splice(0, 16 * j);
    } else {
	for (i = 512+ol - ((512+ol) & 511); i <= nl; i+= 512) {
      	    this._block(b.splice(0,16));
      	}
    }
    return this;
  },
  
  /**
   * Complete hashing and output the hash value.
   * @return {bitArray} The hash value, an array of 8 big-endian words.
   */
  finalize:function () {
    var i, b = this._buffer, h = this._h;

    // Round out and push the buffer
    b = sjcl.bitArray.concat(b, [sjcl.bitArray.partial(1,1)]);
    
    // Round out the buffer to a multiple of 16 words, less the 2 length words.
    for (i = b.length + 2; i & 15; i++) {
      b.push(0);
    }
    
    // append the length
    b.push(Math.floor(this._length / 0x100000000));
    b.push(this._length | 0);

    while (b.length) {
      this._block(b.splice(0,16));
    }

    this.reset();
    return h;
  },

  /**
   * The SHA-256 initialization vector, to be precomputed.
   * @private
   */
  _init:[],
  /*
  _init:[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19],
  */
  
  /**
   * The SHA-256 hash key, to be precomputed.
   * @private
   */
  _key:[],
  /*
  _key:
    [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
     0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
     0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
     0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
     0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
     0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
     0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
     0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2],
  */


  /**
   * Function to precompute _init and _key.
   * @private
   */
  _precompute: function () {
    var i = 0, prime = 2, factor, isPrime;

    function frac(x) { return (x-Math.floor(x)) * 0x100000000 | 0; }

    for (; i<64; prime++) {
      isPrime = true;
      for (factor=2; factor*factor <= prime; factor++) {
        if (prime % factor === 0) {
          isPrime = false;
          break;
        }
      }
      if (isPrime) {
        if (i<8) {
          this._init[i] = frac(Math.pow(prime, 1/2));
        }
        this._key[i] = frac(Math.pow(prime, 1/3));
        i++;
      }
    }
  },
  
  /**
   * Perform one cycle of SHA-256.
   * @param {Uint32Array|bitArray} w one block of words.
   * @private
   */
  _block:function (w) {  
    var i, tmp, a, b,
      h = this._h,
      k = this._key,
      h0 = h[0], h1 = h[1], h2 = h[2], h3 = h[3],
      h4 = h[4], h5 = h[5], h6 = h[6], h7 = h[7];

    /* Rationale for placement of |0 :
     * If a value can overflow is original 32 bits by a factor of more than a few
     * million (2^23 ish), there is a possibility that it might overflow the
     * 53-bit mantissa and lose precision.
     *
     * To avoid this, we clamp back to 32 bits by |'ing with 0 on any value that
     * propagates around the loop, and on the hash state h[].  I don't believe
     * that the clamps on h4 and on h0 are strictly necessary, but it's close
     * (for h4 anyway), and better safe than sorry.
     *
     * The clamps on h[] are necessary for the output to be correct even in the
     * common case and for short inputs.
     */
    for (i=0; i<64; i++) {
      // load up the input word for this round
      if (i<16) {
        tmp = w[i];
      } else {
        a   = w[(i+1 ) & 15];
        b   = w[(i+14) & 15];
        tmp = w[i&15] = ((a>>>7  ^ a>>>18 ^ a>>>3  ^ a<<25 ^ a<<14) + 
                         (b>>>17 ^ b>>>19 ^ b>>>10 ^ b<<15 ^ b<<13) +
                         w[i&15] + w[(i+9) & 15]) | 0;
      }
      
      tmp = (tmp + h7 + (h4>>>6 ^ h4>>>11 ^ h4>>>25 ^ h4<<26 ^ h4<<21 ^ h4<<7) +  (h6 ^ h4&(h5^h6)) + k[i]); // | 0;
      
      // shift register
      h7 = h6; h6 = h5; h5 = h4;
      h4 = h3 + tmp | 0;
      h3 = h2; h2 = h1; h1 = h0;

      h0 = (tmp +  ((h1&h2) ^ (h3&(h1^h2))) + (h1>>>2 ^ h1>>>13 ^ h1>>>22 ^ h1<<30 ^ h1<<19 ^ h1<<10)) | 0;
    }

    h[0] = h[0]+h0 | 0;
    h[1] = h[1]+h1 | 0;
    h[2] = h[2]+h2 | 0;
    h[3] = h[3]+h3 | 0;
    h[4] = h[4]+h4 | 0;
    h[5] = h[5]+h5 | 0;
    h[6] = h[6]+h6 | 0;
    h[7] = h[7]+h7 | 0;
  }
};



/** @fileOverview HMAC implementation.
 *
 * @author Emily Stark
 * @author Mike Hamburg
 * @author Dan Boneh
 */

/** HMAC with the specified hash function.
 * @constructor
 * @param {bitArray} key the key for HMAC.
 * @param {Object} [Hash=sjcl.hash.sha256] The hash function to use.
 */
sjcl.misc.hmac = function (key, Hash) {
  this._hash = Hash = Hash || sjcl.hash.sha256;
  var exKey = [[],[]], i,
      bs = Hash.prototype.blockSize / 32;
  this._baseHash = [new Hash(), new Hash()];

  if (key.length > bs) {
    key = Hash.hash(key);
  }
  
  for (i=0; i<bs; i++) {
    exKey[0][i] = key[i]^0x36363636;
    exKey[1][i] = key[i]^0x5C5C5C5C;
  }
  
  this._baseHash[0].update(exKey[0]);
  this._baseHash[1].update(exKey[1]);
  this._resultHash = new Hash(this._baseHash[0]);
};

/** HMAC with the specified hash function.  Also called encrypt since it's a prf.
 * @param {bitArray|String} data The data to mac.
 */
sjcl.misc.hmac.prototype.encrypt = sjcl.misc.hmac.prototype.mac = function (data) {
  if (!this._updated) {
    this.update(data);
    return this.digest(data);
  } else {
    throw new sjcl.exception.invalid("encrypt on already updated hmac called!");
  }
};

sjcl.misc.hmac.prototype.reset = function () {
  this._resultHash = new this._hash(this._baseHash[0]);
  this._updated = false;
};

sjcl.misc.hmac.prototype.update = function (data) {
  this._updated = true;
  this._resultHash.update(data);
};

sjcl.misc.hmac.prototype.digest = function () {
  var w = this._resultHash.finalize(), result = new (this._hash)(this._baseHash[1]).update(w).finalize();

  this.reset();

  return result;
};

/** @fileOverview Password-based key-derivation function, version 2.0.
 *
 * @author Emily Stark
 * @author Mike Hamburg
 * @author Dan Boneh
 */

/** Password-Based Key-Derivation Function, version 2.0.
 *
 * Generate keys from passwords using PBKDF2-HMAC-SHA256.
 *
 * This is the method specified by RSA's PKCS #5 standard.
 *
 * @param {bitArray|String} password  The password.
 * @param {bitArray|String} salt The salt.  Should have lots of entropy.
 * @param {Number} [count=1000] The number of iterations.  Higher numbers make the function slower but more secure.
 * @param {Number} [length] The length of the derived key.  Defaults to the
                            output size of the hash function.
 * @param {Object} [Prff=sjcl.misc.hmac] The pseudorandom function family.
 * @return {bitArray} the derived key.
 */
sjcl.misc.pbkdf2 = function (password, salt, count, length, Prff) {
  count = count || 10000;
  
  if (length < 0 || count < 0) {
    throw new sjcl.exception.invalid("invalid params to pbkdf2");
  }
  
  if (typeof password === "string") {
    password = sjcl.codec.utf8String.toBits(password);
  }
  
  if (typeof salt === "string") {
    salt = sjcl.codec.utf8String.toBits(salt);
  }
  
  Prff = Prff || sjcl.misc.hmac;
  
  var prf = new Prff(password),
      u, ui, i, j, k, out = [], b = sjcl.bitArray;

  for (k = 1; 32 * out.length < (length || 1); k++) {
    u = ui = prf.encrypt(b.concat(salt,[k]));
    
    for (i=1; i<count; i++) {
      ui = prf.encrypt(ui);
      for (j=0; j<ui.length; j++) {
        u[j] ^= ui[j];
      }
    }
    
    out = out.concat(u);
  }

  if (length) { out = b.clamp(out, length); }

  return out;
};
